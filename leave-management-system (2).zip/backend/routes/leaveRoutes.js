
const router = require("express").Router();
const Leave = require("../models/Leave");
const auth = require("../middleware/authMiddleware");

router.post("/", auth, async (req, res) => {
  const leave = await Leave.create({ ...req.body, userId: req.user.id });
  res.json(leave);
});

router.get("/", auth, async (req, res) => {
  const leaves =
    req.user.role === "employer"
      ? await Leave.find().populate("userId")
      : await Leave.find({ userId: req.user.id });
  res.json(leaves);
});

router.put("/:id", auth, async (req, res) => {
  await Leave.findByIdAndUpdate(req.params.id, { status: req.body.status });
  res.json("Updated");
});

module.exports = router;
